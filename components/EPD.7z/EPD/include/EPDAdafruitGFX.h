#pragma once

#include <Adafruit_GFX.h>
#include "Common.h"
#include "EPDBackBuffer.h"

// Note: GDEW0213I5F is our test display that will be the default initializing this class
class EPDAdafruitGFX : public Adafruit_GFX
{
    EPDBackBuffer& _buffer;
public:
    EPDAdafruitGFX(EPDBackBuffer& pBuffer);
    ~EPDAdafruitGFX();

    void drawPixel(int16_t x, int16_t y, uint16_t color) override;
};