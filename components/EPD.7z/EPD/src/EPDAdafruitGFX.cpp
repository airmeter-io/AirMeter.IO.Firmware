
#include "EPDAdafruitGFX.h"
EPDAdafruitGFX::EPDAdafruitGFX(EPDBackBuffer& pBuffer) : Adafruit_GFX(pBuffer.GetWidth(), pBuffer.GetHeight()), _buffer(pBuffer) {

}

EPDAdafruitGFX::~EPDAdafruitGFX() {

}

void EPDAdafruitGFX::drawPixel(int16_t x, int16_t y, uint16_t color) {
  if ((x < 0) || (x >= _buffer.GetWidth()) || (y < 0) || (y >= _buffer.GetHeight())) return;

//   // check rotation, move pixel around if necessary
//   switch (getRotation())
//   {
//     case 1:
//       swap(x, y);
//       x = Gdepg0213BN_WIDTH - x - 1;
//       break;
//     case 2:
//       x = Gdepg0213BN_WIDTH - x - 1;
//       y = Gdepg0213BN_HEIGHT - y - 1;
//       break;
//     case 3:
//       swap(x, y);
//       y = Gdepg0213BN_HEIGHT - y - 1;
//       break;
//   }
  uint16_t i = x / 8 + y *  _buffer.GetWidth() / 8;

  // This is the trick to draw colors right. Genious Jean-Marc
  if (color) {
    _buffer.GetBuffer()[i] = (_buffer.GetBuffer()[i] & (0xFF ^ (1 << (7 - x % 8))));
    } else {
    _buffer.GetBuffer()[i] = (_buffer.GetBuffer()[i] | (1 << (7 - x % 8)));
    }
}
