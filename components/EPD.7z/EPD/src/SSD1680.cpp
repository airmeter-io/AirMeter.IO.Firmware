#include "SSD1680.h"

#define TAG "SSD1680"
SSD1680::SSD1680(EpdSpi& pSpi) : _spi(pSpi){

}

SSD1680::~SSD1680() {

}

void SSD1680::ResetAll() {
    _spi.cmd(ResetAllCommandsAndParameter);
   WaitBusy("epd_wakeup_power:ON"); 
}

void SSD1680::SetRamDataEntryMode(SSD1680RamDataEntryMode pMode, uint16_t pWidth, uint16_t pHeight) {

    _spi.cmd(DefineDataEntrySequence);
    _spi.data(pMode);
    switch (pMode)
    {
        case XDecreaseYDescrease: // x decrease, y decrease
            SetRamArea(pWidth / 8, 0, pHeight, 0);  // X-source area,Y-gate area
            SetRamPointer(pWidth / 8, pHeight); // set ram
            break;
        case XIncreaseYDecrease: // x increase, y decrease : as in demo code
            SetRamArea(0, pWidth / 8, pHeight, 0);  // X-source area,Y-gate area
            SetRamPointer(0, pHeight); // set ram
            break;
        case XDecreaseYIncrease: // x decrease, y increase
            SetRamArea(pWidth / 8, 0,0, pHeight);  // X-source area,Y-gate area
            SetRamPointer(pWidth / 8, 0); // set ram
            break;
        case XIncreaseYIncrease: // x increase, y increase : normal mode
            SetRamArea(0, pWidth / 8, 0, pHeight);  // X-source area,Y-gate area
            SetRamPointer(0, 0); // set ram
            break;
    }
}


void SSD1680::SetRamArea(uint8_t pXStart, uint8_t pXEnd, uint16_t pYStart, uint16_t pYEnd) {
    _spi.cmd(SetRamXAddressRange);
    _spi.data(pXStart+1);
    _spi.data(pXEnd+1);
    _spi.cmd(SetRamYAddressRange);
    _spi.data(pYStart % 255);
    _spi.data(pYStart / 255);
    _spi.data(pYEnd % 255);
    _spi.data(pYEnd / 255);
}


void SSD1680::SetRamPointer(uint8_t pX, uint16_t pY) {
    _spi.cmd(SetRamXAddressCounter);
    _spi.data(pX+1);
    _spi.cmd(SetRamYAddressCounter);
    _spi.data(pY % 255);
    _spi.data(pY /255);
}


void SSD1680::SetSleepMode(SSD1306SleepMode pMode) {
    _spi.cmd(EnterDeepSleep); // power off display
    _spi.data(pMode);
    WaitBusy("power_off");
}


void SSD1680::WriteToBWRam(EPDBackBuffer& pBuffer) {
    _spi.cmd(SSD1680Cmd::WriteToBWRam);        // update current data
    auto dataLen = (pBuffer.GetWidth() / 8)*pBuffer.GetHeight();
    uint8_t *sendBuffer = (uint8_t *)malloc(dataLen);
    printf("Building...\n");
    for (uint16_t y = 0; y < pBuffer.GetHeight(); y++)
    {
        for (uint16_t x = 0; x < pBuffer.GetWidth() / 8; x++)
        {
            uint16_t idx = y * (pBuffer.GetWidth() / 8) + x;
            uint8_t data = (idx < pBuffer.GetBufferLength()) ? pBuffer.GetBuffer()[idx] : 0x00;
           // _spi.data(~data);
            sendBuffer[idx] = ~data;
        }
    }
    printf("Sending...\n");
    _spi.data(sendBuffer,dataLen);
    printf("Sent..\n");
    free(sendBuffer);
}

void SSD1680::ActivateDisplayUpdateSequence() {
    _spi.cmd(SSD1680Cmd::ActivateDisplayUpdateSequence);
    WaitBusy("_Update_Full", 1200);
}

void SSD1680::SetDisplayUpdateSequence(SSD1680DisplayUpdateSequence pSequence) {
    _spi.cmd(SSD1680Cmd::DisplayUpdateSequence);
    _spi.data(pSequence);
}

void SSD1680::SendLUT(SSD1680Lut& pLut) {
  //  uint8_t buffer[sizeof(pLut.Data)+1];
  //  buffer[0] = SSD1680Cmd::SendLUT;
 //   memcpy(buffer+1, pLut.Data, sizeof(pLut.Data));
    _spi.cmd(SSD1680Cmd::SendLUT);
    _spi.data(pLut.Data,sizeof(pLut.Data));
}

void SSD1680::SendEndLUT(SSD1680LutEndOption pOption) {
    _spi.cmd(SSD1680Cmd::EndOptionLUT);
    _spi.data(SSD1680LutEndOption::Normal);
}

void SSD1680::SetGateDrivingVoltage(SSD1680Lut& pLut) {
    if(pLut.GateDrivingVoltage<100 || pLut.GateDrivingVoltage>200 || pLut.GateDrivingVoltage%5!=0) {
        printf("Voltage must be between 10v and 20v and in 0.5v increments\n");
        return;
    }
    uint8_t voltage = 3 + (pLut.GateDrivingVoltage-100)/5;
    _spi.cmd(SSD1680Cmd::SetGateDrivingVoltage);
    _spi.data(voltage);
}

void SSD1680::SetSourceDrivingVoltage(SSD1680Lut& pLut) {
    if(pLut.SourceDrivingVoltage.Vsh1<24 || pLut.SourceDrivingVoltage.Vsh1>170 || (pLut.SourceDrivingVoltage.Vsh1 > 88 && pLut.SourceDrivingVoltage.Vsh1%2!=0)) {
        printf("VSH1 must be between 24 and 170 and after 8.8v be incremented in .2v intervals\n");
        return;
    }
    

    if( (pLut.SourceDrivingVoltage.Vsh2<24 && pLut.SourceDrivingVoltage.Vsh2!=0) || pLut.SourceDrivingVoltage.Vsh2>170 || (pLut.SourceDrivingVoltage.Vsh2 > 88 && pLut.SourceDrivingVoltage.Vsh2%2!=0)) {
        printf("VSH2 must be between 24 and 170 and after 8.8v be incremented in .2v intervals\n");
        return;
    }

    if(pLut.SourceDrivingVoltage.Vsl> -55 || pLut.SourceDrivingVoltage.Vsl< -170 || pLut.SourceDrivingVoltage.Vsl%5!=0) {
        printf("VSL must be between -5.5v and -17v\n");
        return;
    }

    uint8_t vsh1 = pLut.SourceDrivingVoltage.Vsh1 <= 88 ? 0x8e  + (pLut.SourceDrivingVoltage.Vsh1-24) : 0x23+(pLut.SourceDrivingVoltage.Vsh1-90)/2;
    uint8_t vsh2 = pLut.SourceDrivingVoltage.Vsh2==0 ? 0 : pLut.SourceDrivingVoltage.Vsh2 <= 88 ? 0x8e  + (pLut.SourceDrivingVoltage.Vsh2-24) : 0x23+(pLut.SourceDrivingVoltage.Vsh2-90)/2;
    uint8_t vsl = 0xC+((abs(pLut.SourceDrivingVoltage.Vsl)-55)/5)*2;
    _spi.cmd(SSD1680Cmd::SetSourceDrivingVoltage);
    _spi.data(vsh1);
    _spi.data(vsh2);
    _spi.data(vsl);
}

void SSD1680::SetVCOMRegister(SSD1680Lut& pLut) {
    _spi.cmd(SSD1680Cmd::WriteVCOMRegister);
    _spi.data(pLut.VCOM);
}

void SSD1680::EnablePingPong() {
    _spi.cmd(WriteRegisterForDisplayOption);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x40);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x00);
    _spi.data(0x00);
}

void SSD1680::SetBorderWaveForm(uint8_t pValue) {
    _spi.cmd(SSD1680Cmd::SetBorderWaveForm);
    _spi.data(pValue);
}

void SSD1680::WaitBusy(const char* message, uint16_t busy_time){

  int64_t time_since_boot = esp_timer_get_time();
  // On high is busy
  if (gpio_get_level((gpio_num_t)CONFIG_EINK_BUSY) == 1) {
  while (1){
    if (gpio_get_level((gpio_num_t)CONFIG_EINK_BUSY) == 0) break;
    vTaskDelay(1);//portTICK_RATE_MS);
    if (esp_timer_get_time()-time_since_boot>7000000)
    {
     
      break;
    }
  }
  } else {
    vTaskDelay(busy_time/portTICK_RATE_MS); 
  }
}

void SSD1680::WaitBusy(const char* message){
  int64_t time_since_boot = esp_timer_get_time();

  while (1){
    // On low is not busy anymore
    if (gpio_get_level((gpio_num_t)CONFIG_EINK_BUSY) == 0) break;
    vTaskDelay(1);///portTICK_RATE_MS);
    if (esp_timer_get_time()-time_since_boot>7000000)
    {
   
      break;
    }
  }
}
